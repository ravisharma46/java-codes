package trees;

import java.util.ArrayList;

public class ListDemo {

	public static void main(String[] args) {
		int arr[] = {10,20,30,40};
		for(int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
			arr[i] = 10;
		}
		// For each
		for(int i : arr) {
			System.out.println(i);
			i = 0;
		}
		for(int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
		}
//		ArrayList<Integer> list = new ArrayList<>();
//		for(int i = 0; i < 10; i++) {
//			list.add(i);
//		}
		
		
		
//		list.add(0, 100);
//		list.remove(1);
//		System.out.println(list.size());
//		System.out.println(list.get(0));
//		list.set(0, 200);
//		System.out.println(list.size());
//		System.out.println(list.get(0));
		

	}

}
