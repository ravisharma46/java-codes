package trees;

import java.util.Scanner;

import stacks_and_queues.QueueEmptyException;
import stacks_and_queues.QueueUsingLL;

public class BinaryTreeUse {

	
	public static BinaryTreeNode<Integer> takeInputLevelWise(){
		
		Scanner s = new Scanner(System.in);
		System.out.println("Enter root ");
		int rootData = s.nextInt();
		BinaryTreeNode<Integer> root = new BinaryTreeNode<Integer>(rootData);
		QueueUsingLL<BinaryTreeNode<Integer>> pendingNodes = new QueueUsingLL<>();
		pendingNodes.enqueue(root);
		
		while(! pendingNodes.isEmpty()) {
			try {
				BinaryTreeNode<Integer> currentNode = pendingNodes.dequeue();
				System.out.println("Enter left child of " + currentNode.data);
				int leftChildData = s.nextInt();
				if(leftChildData != -1) {
					BinaryTreeNode<Integer> leftChild = new BinaryTreeNode<Integer>(leftChildData);
					pendingNodes.enqueue(leftChild);
					currentNode.left = leftChild;
				}
				System.out.println("Enter right child of " + currentNode.data);
				int rightChildData = s.nextInt();
				if(rightChildData != -1) {
					BinaryTreeNode<Integer> rightChild = new BinaryTreeNode<Integer>(rightChildData);
					pendingNodes.enqueue(rightChild);
					currentNode.right = rightChild;
				}	
			} catch (QueueEmptyException e) {
			}	
		}	
		return root;
	}
	
	public static void print(BinaryTreeNode<Integer> root) {
		if(root == null) {
			return;
		}
		System.out.print(root.data+": ");
		if(root.left != null)
			System.out.print(root.left.data+", ");
		else {
			System.out.print(-1+", ");
		}
		if(root.right != null)
			System.out.println(root.right.data);
		else {
			System.out.println(-1);
		}	
		print(root.left);
		print(root.right);
		
	}
	
	public static int count(BinaryTreeNode<Integer> root) {
//		if(root == null) {
//			return 0;
//		}
//		return count(root.left) + count(root.right) + 1;
		return root == null ? 0 : count(root.left) + count(root.right) + 1;
		
	}
	
	// 6 3 4 5 -1 1 9 -1 8 -1 -1 -1 -1 -1 -1
	public static void main(String[] args) {
		
		int a = 10;
		int b = 20;
		int c = a > b ? a : b;
		
		BinaryTreeNode<Integer> root = takeInputLevelWise();
		print(root);
	}

}
